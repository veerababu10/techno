## Fizz Buzz Example in Java 8 using JUnit 5

### Fizz Buzz is a game where
- if the number is divisible by 3, you say Fizz
- if the number is divisible by 5, you say Buzz
- if neither, you say the number